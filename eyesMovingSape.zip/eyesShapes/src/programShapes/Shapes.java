package programShapes;

import java.util.Random;

import javafx.scene.Group;
import javafx.scene.Scene;


public class Shapes extends Eyes {
	public enum KindOfShape{CIRCLESHAPE,RECTANGLE,TRIANGULARUP,TRIANGULARDOWN,RHOMBUS};
	public final int MAX_INTENCITY = 255;
	protected int red, green, blue;
	private int x;
	private int y;
	protected Eye left,right;
	private int maxNumEyesShapes=9;
	private int currentNumEyesShapes;
private Shapes[] allShapes;
	private Eyes[] allEyes;
	//private int cellWidth,cellHeight;
	Group root = new Group();
	Scene scene = new Scene(root,800,600);
	Random rnd = new Random();
	
	public Shapes(int x,int y) {
		super(x,y);
		this.x=x;
		this.y=y;
		allShapes= new Shapes[maxNumEyesShapes];
		currentNumEyesShapes=0;
		
		
	}

	public void addEyesShapes(KindOfShape kind) {
		if(currentNumEyesShapes < maxNumEyesShapes) {
			
			int red=0,green=0,blue=0;

		
			red = rnd.nextInt(255);
			green = rnd.nextInt(255);
			blue = rnd.nextInt(255);
			switch(kind) {
			case CIRCLESHAPE:
			
				
				allShapes[currentNumEyesShapes]= new CircleShape(x+20,y+20,30,red,green,blue);
				
				
				break; 
			case RECTANGLE:
				
				
				allShapes[currentNumEyesShapes]= new RectangleShape(x-25,y-25,80,80,red,green,blue);
			
				
				break;
			case TRIANGULARUP:
				
				
				allShapes[currentNumEyesShapes]= new TriangularUp(x,y,red,green,blue);
			
				
				break; 
			case TRIANGULARDOWN:
				
				
				allShapes[currentNumEyesShapes]= new TriangleDown(x,y,red,green,blue);
			
				
				break; 
			case RHOMBUS:
				
				
				allShapes[currentNumEyesShapes]= new Rhombus(x,y,red,green,blue);
			
				
				break;
				default:
					System.out.println("Error: Wrong kind of shape");
					currentNumEyesShapes--;
					
			}
			// in any case
			currentNumEyesShapes++;
		}
		else {
			System.out.println("shapes place is full");
		}
	}
	
	



	public int getX() {
		return x;
	}

	public int setX(int x) {
		return this.x = x;
	}

	public int getY() {
		return y;
	}

	public int setY(int y) {
		return this.y = y;
	}

	public void setShapesArr(Eyes e) {
		allEyes[currentNumEyesShapes].update(e.getX(), e.getY());
	}


	public void show(Group root ) {
		super.show(root);
		for(int i = 0; i<currentNumEyesShapes;i++)
		
			allShapes[i].show(root);
	}
}