package programShapes;

import java.util.Random;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

public class Main extends Application{
	 
	public static void main(String[] args) {
		launch(args); // launches application
	}

	@Override
	public void start(Stage stage) throws Exception {

		Random rnd = new Random();

		Shapes s1 = new Shapes(300,200);

		// 1. define root node
		Group root = new Group();
		// 2. define Scene basing on root
		Scene scene = new Scene(root,800,600);


		Button addChercle = new Button("Add circle");
		addChercle.setLayoutX(650);
		addChercle.setLayoutY(100);
		addChercle.setOnAction(new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent arg0) {
				Eyes newEyes= new Eyes(s1.getX(),s1.getY());
				s1.addEyesShapes(Shapes.KindOfShape.CIRCLESHAPE);
				s1.setX(rnd.nextInt(800-100)+100);
				s1.setY(rnd.nextInt(600-100)+100);
				s1.show(root);

				EventHandler<MouseEvent> motionEvent = new EventHandler<MouseEvent>() {

					@Override
					public void handle(MouseEvent ev) {

						int x1 = (int)ev.getX();
						int y1 = (int)ev.getY();				
						newEyes.update(x1, y1);
						root.getChildren();

						newEyes.show(root);
						//s1.show(root);

					}
				};
				scene.addEventHandler(MouseEvent.MOUSE_MOVED, motionEvent);


			}

		});
		Button addRectangle = new Button("Add Rectangle");

		addRectangle.setLayoutX(650);
		addRectangle.setLayoutY(250);

		addRectangle.setOnAction(new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent arg0) {
				Eyes newEyes= new Eyes(s1.getX(),s1.getY());
				s1.addEyesShapes(Shapes.KindOfShape.RECTANGLE);
				s1.setX(rnd.nextInt(800-100)+100);
				s1.setY(rnd.nextInt(600-100)+100);
				s1.show(root);
				//newEyes.show(root);
				EventHandler<MouseEvent> motionEvent = new EventHandler<MouseEvent>() {

					@Override
					public void handle(MouseEvent ev) {
						int x1 = (int)ev.getX();
						int y1 = (int)ev.getY();

						newEyes.update(x1, y1);
						root.getChildren();
						newEyes.show(root);
						//s1.show(root);

					}
				};
				scene.addEventHandler(MouseEvent.MOUSE_MOVED, motionEvent);


			}

		});
		Button addTriangularUp = new Button("Add TriangularUp");

		addTriangularUp.setLayoutX(650);
		addTriangularUp.setLayoutY(350);
		addTriangularUp.setOnAction(new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent arg0) {
				Eyes newEyes= new Eyes(s1.getX(),s1.getY());
				s1.addEyesShapes(Shapes.KindOfShape.TRIANGULARUP);
				s1.setX(rnd.nextInt(800-100)+100);
				s1.setY(rnd.nextInt(600-100)+100);
				s1.show(root);

				//newEyes.show(root);
				EventHandler<MouseEvent> motionEvent = new EventHandler<MouseEvent>() {

					@Override
					public void handle(MouseEvent ev) {


						int x1 = (int)ev.getX();
						int y1 = (int)ev.getY();


						newEyes.update(x1, y1);
						root.getChildren();

						newEyes.show(root);
						//s1.show(root);

					}
				};
				scene.addEventHandler(MouseEvent.MOUSE_MOVED, motionEvent);


			}

		});

		Button addTriangularDouwn = new Button("Add TriangularDown");

		addTriangularDouwn.setLayoutX(650);
		addTriangularDouwn.setLayoutY(450);
		addTriangularDouwn.setOnAction(new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent arg0) {
				Eyes newEyes= new Eyes(s1.getX(),s1.getY());
				s1.addEyesShapes(Shapes.KindOfShape.TRIANGULARDOWN);
				s1.setX(rnd.nextInt(800-100)+100);
				s1.setY(rnd.nextInt(600-100)+100);
				s1.show(root);

				//newEyes.show(root);
				EventHandler<MouseEvent> motionEvent = new EventHandler<MouseEvent>() {

					@Override
					public void handle(MouseEvent ev) {


						int x1 = (int)ev.getX();
						int y1 = (int)ev.getY();


						newEyes.update(x1, y1);
						root.getChildren();

						newEyes.show(root);
						//s1.show(root);

					}
				};
				scene.addEventHandler(MouseEvent.MOUSE_MOVED, motionEvent);


			}

		});
		Button addRhombus = new Button("Add Rhombus");

		addRhombus.setLayoutX(650);
		addRhombus.setLayoutY(550);
		addRhombus.setOnAction(new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent arg0) {
				Eyes newEyes= new Eyes(s1.getX(),s1.getY());
				s1.addEyesShapes(Shapes.KindOfShape.RHOMBUS);
				s1.setX(rnd.nextInt(800-100)+100);
				s1.setY(rnd.nextInt(600-100)+100);
				s1.show(root);

				//newEyes.show(root);
				EventHandler<MouseEvent> motionEvent = new EventHandler<MouseEvent>() {

					@Override
					public void handle(MouseEvent ev) {


						int x1 = (int)ev.getX();
						int y1 = (int)ev.getY();


						newEyes.update(x1, y1);
						root.getChildren();

						newEyes.show(root);
						//s1.show(root);

					}
				};
				scene.addEventHandler(MouseEvent.MOUSE_MOVED, motionEvent);


			}

		});
		root.getChildren().addAll(addChercle,addRectangle,addTriangularUp,addTriangularDouwn,addRhombus);


		// 3. add scene to stage
		stage.setScene(scene);
		// 4. show the window
		stage.show();
	}
}