package programShapes;

import javafx.scene.paint.Color;
import javafx.scene.Group;


import javafx.scene.*;
import javafx.scene.shape.*;
public class Eye {
protected int centerX, centerY, eyeRadius;
protected int pupilX, pupilY, pupilRadius;
	
	public Eye(int cx,int cy,int R, int r ) {
		centerX=cx;
		centerY=cy;
		eyeRadius=R;
		pupilRadius=r;
		pupilX=cx;
		pupilY=cy;
		
		
	}
	
	
	public void upDate(int mx, int my) {
		double dx,dy;
		double len;
		
		
		dx=mx-centerX;
		dy=my-centerY;
		len=Math.sqrt(dx*dx+dy*dy);
		dx=dx/len;
		dy/=len;
		
		pupilX=(int)(centerX+dx*(eyeRadius-pupilRadius));
		pupilY=(int)(centerY+dy*(eyeRadius-pupilRadius));
	}
	
	public void show(Group root) {
		Circle big = new Circle(centerX,centerY,eyeRadius);
		big.setFill(Color.WHITE);
		big.setStroke(Color.BLACK);
		Circle pupil = new Circle(pupilX,pupilY,pupilRadius);
		pupil.setFill(Color.BLACK);
		
		root.getChildren().addAll(big,pupil);
	}
}