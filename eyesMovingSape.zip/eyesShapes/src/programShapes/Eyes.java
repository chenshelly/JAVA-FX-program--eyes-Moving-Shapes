package programShapes;

import javafx.scene.Group;

public class Eyes {
	
protected Eye left,right;
protected int x=0;
protected int y=0;


public  Eyes(int x,int y) {
	this.x=x;
	this.y=y;
	left= new Eye(x-15,y,20,7);
	right=new Eye(x+40,y,20,7);
}
public  Eyes() {
	
}
public void update(int mx,int my) {
	left.upDate(mx,my);
	right.upDate(mx,my);
}
public  Eyes(Eyes e) {
	this.x=e.x;
	this.y=e.y;
	left= new Eye(x-50,y,20,5);
	right=new Eye(x+30,y,20,5);
}

public Eye getLeft() {
	return left;
}

public void setLeft(Eye l) {
	this.left=l;
}

public Eye getRight() {
	return right;
}

public void setRight(Eye r) {
	this.right = r;
}

public int getX() {
	return left.pupilX;
}

public int setX(int x) {
	return this.x = x;
}

public int getY() {
	return right.pupilY;
}

public int setY(int y) {
	return this.y = y;
}

public void show(Group root) {
	
	left.show(root);
	right.show(root);
}


}



