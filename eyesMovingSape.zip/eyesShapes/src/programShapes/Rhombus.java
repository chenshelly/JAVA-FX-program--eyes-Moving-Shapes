package programShapes;

import javafx.scene.Group;
import javafx.scene.paint.Color;
import javafx.scene.shape.Polygon;
import javafx.scene.shape.Rectangle;

public class Rhombus extends Shapes{
	protected  double width;
	protected double height;
	protected int x,y;
	int red,green,blue;
	public final int MAX_INTENCITY = 255;
		public Rhombus(int x, int y, int red,int green,int blue) {
			super(x, y);
			
			this.x=x;
			this.y=y;
			setRed(red);
			setGreen(green);
			setBlue(blue);
		}
		


		public void setRed(int red) {
			if(red>=0 && red<=MAX_INTENCITY) 
				this.red = red;
			else
				this.red = 0;
		}

		public void setGreen(int green) {
			if(green>=0 && green<=MAX_INTENCITY)
				this.green = green;
			else 
				this.green = 0;
		}

		public void setBlue(int blue) {
			if(blue>=0 && blue <=MAX_INTENCITY)
				this.blue = blue;
			else
				this.blue = 0;
		}
		
		
		public void show(Group root) {
			Polygon up= new Polygon();
			up.getPoints().addAll((new Double[] {(double)x+10,(double)y-20,
					(double)x-30,(double)y+30,
					(double)x+50,(double)y+30}));
			Polygon pd = new Polygon();
			pd.getPoints().addAll((new Double[] {(double)x-30,(double)y+30,
					(double)x+50,(double)y+30,
					(double)x+10,(double)y+70}));
			Color color= Color.rgb(red, green, blue);
				up.setFill(color);
				pd.setFill(color);
				root.getChildren().addAll(up,pd);
				
				
			}
		
}
