package programShapes;



import java.beans.EventHandler;

import javafx.scene.Group;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;

public class CircleShape extends Shapes{
protected int radius;
	protected int x,y;
	int red,green,blue;
	public final int MAX_INTENCITY = 255;



	public CircleShape(int x, int y,int radius, int red,int green,int blue) {
		super(x,y);
		this.radius = radius;
		this.x = x;
		this.y = y;
		setRed(red);
		setGreen(green);
		setBlue(blue);
	}

	public void setRed(int red) {
		if(red>=0 && red<=MAX_INTENCITY) 
			this.red = red;
		else
			this.red = 0;
	}

	public void setGreen(int green) {
		if(green>=0 && green<=MAX_INTENCITY)
			this.green = green;
		else 
			this.green = 0;
	}

	public void setBlue(int blue) {
		if(blue>=0 && blue <=MAX_INTENCITY)
			this.blue = blue;
		else
			this.blue = 0;
	}

	public void show(Group root) {
	//super.show(root);
		Circle c = new Circle(x,y,radius);
		c.setFill(Color.rgb(red, green, blue));
		c.setStroke(Color.BLACK);
		root.getChildren().add(c);
		
		
	}
	

}
